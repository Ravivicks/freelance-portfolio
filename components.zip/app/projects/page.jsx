"use client";
import ProjectCard from "@/components/ProjectCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import React from "react";

const projectData = [
  {
    image: "/work/w1.png",
    category: "react js",
    name: "Snapgram Social Media App",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem ipsa architecto nostrum eos",
    link: "/",
    github: "/",
  },
  {
    image: "/work/w2.png",
    category: "next js",
    name: "Digitalhippo E-commerce ",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem ipsa architecto nostrum eos",
    link: "/",
    github: "/",
  },
  {
    image: "/work/w3.jpg",
    category: "full stack",
    name: "SMC Tradeonline Admin",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem ipsa architecto nostrum eos",
    link: "/",
    github: "/",
  },
  {
    image: "/work/w4.jpg",
    category: "react js",
    name: "SMC Tradeonline Portal",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem ipsa architecto nostrum eos",
    link: "/",
    github: "/",
  },
  {
    image: "/work/w5.jpg",
    category: "react js",
    name: "Stoxkart Web Trading Plateform",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem ipsa architecto nostrum eos",
    link: "/",
    github: "/",
  },
  {
    image: "/work/w7.jpg",
    category: "full stack",
    name: "SMC Partner Portal",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem ipsa architecto nostrum eos",
    link: "/",
    github: "/",
  },
  {
    image: "/work/w6.jpg",
    category: "react js",
    name: "Stoxkart Rekyc Portal",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem ipsa architecto nostrum eos",
    link: "/",
    github: "/",
  },
];

// remove duplicates category
const uniqueCategories = [
  "all projects",
  ...new Set(projectData.map((item) => item.category)),
];

const Projects = () => {
  const [categories, setCategories] = React.useState(uniqueCategories);
  const [category, setCategory] = React.useState("all projects");

  const filteredProjects = projectData.filter((project) => {
    // if category is 'all projects' return all project else filter by category
    return category === "all projects"
      ? project
      : project.category === category;
  });

  return (
    <section className="min-h-screen pt-12">
      <div className="container mx-auto">
        <h2 className="section-title mb-8 xl:mb-16 text-center mx-auto">
          My Projects
        </h2>
        {/* tabs */}
        <Tabs defaultValue={category} className="mb-24 xl:mb-48">
          <TabsList className="w-full grid h-full md:grid-cols-4 lg:max-w-[640px] mb-12 mx-auto md:border dark:border-none">
            {categories.map((category, index) => {
              return (
                <TabsTrigger
                  onClick={() => setCategory(category)}
                  value={category}
                  key={index}
                  className="capitalize w-[162px] md:w-auto"
                >
                  {category}
                </TabsTrigger>
              );
            })}
          </TabsList>
          {/* tabs content */}
          <div className="text-lg xl:mt-8 grid grid-cols-1 lg:grid-cols-3 gap-4">
            {filteredProjects.map((project, index) => {
              return (
                <TabsContent value={category} key={index}>
                  <ProjectCard project={project} />
                </TabsContent>
              );
            })}
          </div>
        </Tabs>
      </div>
    </section>
  );
};

export default Projects;
