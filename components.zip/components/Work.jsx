"use client";
import Link from "next/link";
import { Button } from "./ui/button";

// components
import ProjectCard from "./ProjectCard";

// import swiper react components
import { Swiper, SwiperSlide } from "swiper/react";

// import swiper css
import "swiper/css";
import "swiper/css/pagination";

// import required modules
import { Pagination } from "swiper/modules";

const projectData = [
  {
    image: "/work/w1.png",
    category: "react js",
    name: "Snapgram social media app",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem ipsa architecto nostrum eos",
    link: "/",
    github: "/",
  },
  {
    image: "/work/w2.png",
    category: "next js",
    name: "digitalhippo e-commerce ",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem ipsa architecto nostrum eos",
    link: "/",
    github: "/",
  },
  {
    image: "/work/w3.jpg",
    category: "full stack",
    name: "SMC tradeonline Admin",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem ipsa architecto nostrum eos",
    link: "/",
    github: "/",
  },
  {
    image: "/work/w4.jpg",
    category: "React js",
    name: "SMC Tradeonline portal",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem ipsa architecto nostrum eos",
    link: "/",
    github: "/",
  },
  {
    image: "/work/w5.jpg",
    category: "React js",
    name: "Stoxkart web trading",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem ipsa architecto nostrum eos",
    link: "/",
    github: "/",
  },
  {
    image: "/work/w7.jpg",
    category: "Full stack",
    name: "SMC Partner portal",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem ipsa architecto nostrum eos",
    link: "/",
    github: "/",
  },
  {
    image: "/work/w6.jpg",
    category: "React js",
    name: "Stoxkart Rekyc portal",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem ipsa architecto nostrum eos",
    link: "/",
    github: "/",
  },
];

const Work = () => {
  return (
    <section className="relative mb-12 xl:mb-48">
      <div className="container mx-auto">
        {/* text */}
        <div className="max-w-[400px] mx-auto xl:mx-0 text-center xl:text-left mb-12 xl:h-[400px] flex flex-col justify-center items-center xl:items-start">
          <h2 className="section-title mb-4">Latest Projects</h2>
          <p className="subtitle mb-8">
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Delectus
            voluptatem rem quas! Eos vel sequi ipsam eum ratione at numquam,
            officiis doloremque, eius blanditiis, necessitatibus fuga voluptatum
            provident tempora deleniti.
          </p>
          <Link href="/projects">
            <Button>All Projects</Button>
          </Link>
        </div>
        {/* slider */}
        <div className="xl:max-w-[1000px] xl:absolute right-0 top-0">
          <Swiper
            className="h-[480px]"
            slidesPerView={1}
            breakpoints={{
              640: {
                slidesPerView: 2,
              },
            }}
            spaceBetween={30}
            modules={[Pagination]}
            pagination={{ clickable: true }}
          >
            {/* show only the first 4 projects for the slide */}
            {projectData.slice(0, 4).map((project, index) => {
              return (
                <SwiperSlide key={index}>
                  <ProjectCard project={project} />
                </SwiperSlide>
              );
            })}
          </Swiper>
        </div>
      </div>
    </section>
  );
};

export default Work;
